import React from 'react';
import './Off.scss';

export default function Off() {
  return (
    <span className="toggle disabled">
      <span />
    </span>
  );
}
